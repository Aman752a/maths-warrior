class Question {
  final String id, question, subject, topic, difficulty, explanation;
  final List<String> options;
  final int correctIndex;
  final bool active;
  Question({required this.id, required this.question, required this.options, required this.correctIndex, required this.subject, required this.topic, required this.difficulty, required this.explanation, this.active = true});
  factory Question.fromMap(String id, Map<String, dynamic> m) => Question(
    id: id,
    question: '${m['question'] ?? ''}',
    options: List<String>.from(m['options'] ?? const []),
    correctIndex: (m['correctIndex'] as num?)?.toInt() ?? 0,
    subject: '${m['subject'] ?? 'Maths'}',
    topic: '${m['topic'] ?? 'General'}',
    difficulty: '${m['difficulty'] ?? 'Medium'}',
    explanation: '${m['explanation'] ?? ''}',
    active: m['active'] != false,
  );
  Map<String, dynamic> toMap() => {'question': question, 'options': options, 'correctIndex': correctIndex, 'subject': subject, 'topic': topic, 'difficulty': difficulty, 'explanation': explanation, 'active': active};
}
