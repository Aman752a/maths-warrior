import 'dart:convert';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/services.dart';
import 'models.dart';

class AuthService {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static Stream<User?> get authState => _auth.authStateChanges();
  static User? get user => _auth.currentUser;
  static Future<void> login(String email, String password) => _auth.signInWithEmailAndPassword(email: email.trim(), password: password);
  static Future<void> signup(String name, String email, String password) async {
    final c = await _auth.createUserWithEmailAndPassword(email: email.trim(), password: password);
    await FirebaseFirestore.instance.collection('users').doc(c.user!.uid).set({'name': name.trim(), 'email': email.trim(), 'score': 0, 'attempts': 0, 'correct': 0, 'createdAt': FieldValue.serverTimestamp()}, SetOptions(merge: true));
  }
  static Future<void> logout() => _auth.signOut();
}

class DataService {
  static final db = FirebaseFirestore.instance;
  static Future<List<Question>> localQuestions() async {
    final raw = await rootBundle.loadString('assets/ssc_gd_seed_question_bank.json');
    final list = jsonDecode(raw) as List;
    return list.asMap().entries.map((e) => Question.fromMap('local_${e.key}', Map<String, dynamic>.from(e.value))).toList();
  }
  static Future<List<Question>> questions({String? subject, String? difficulty, int limit = 50}) async {
    Query q = db.collection('questionBank').where('active', isEqualTo: true);
    if (subject != null) q = q.where('subject', isEqualTo: subject);
    if (difficulty != null) q = q.where('difficulty', isEqualTo: difficulty);
    try {
      final s = await q.limit(limit).get();
      if (s.docs.isNotEmpty) { final result = s.docs.map((d) => Question.fromMap(d.id, d.data() as Map<String, dynamic>)).toList(); result.shuffle(Random()); return result.take(min(limit, result.length)).toList(); }
    } catch (_) {}
    var local = await localQuestions();
    if (subject != null) local = local.where((x) => x.subject == subject).toList();
    if (difficulty != null) local = local.where((x) => x.difficulty == difficulty).toList();
    local.shuffle(Random());
    return local.take(min(limit, local.length)).toList();
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> attempts() {
    final uid = AuthService.user!.uid;
    return db.collection('users').doc(uid).collection('attempts').orderBy('createdAt', descending: true).limit(50).snapshots();
  }
  static Future<void> saveAttempt({required String title, required int total, required int correct, required int wrong, required int unanswered, required int score}) async {
    final uid = AuthService.user!.uid;
    final ref = db.collection('users').doc(uid);
    await ref.collection('attempts').add({'title': title, 'total': total, 'correct': correct, 'wrong': wrong, 'unanswered': unanswered, 'score': score, 'percentage': total == 0 ? 0 : correct * 100 / total, 'createdAt': FieldValue.serverTimestamp()});
    await db.runTransaction((tx) async {
      final snap = await tx.get(ref);
      final m = snap.data() ?? {};
      tx.set(ref, {'attempts': ((m['attempts'] as num?)?.toInt() ?? 0) + 1, 'correct': ((m['correct'] as num?)?.toInt() ?? 0) + correct, 'score': ((m['score'] as num?)?.toInt() ?? 0) + score}, SetOptions(merge: true));
    });
  }
}
