import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'models.dart';
import 'services.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final email = TextEditingController();
  final pass = TextEditingController();
  final name = TextEditingController();
  bool signup = false;
  bool busy = false;

  Future<void> submit() async {
    if (email.text.trim().isEmpty || pass.text.isEmpty || (signup && name.text.trim().isEmpty)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Please fill all fields')));
      return;
    }
    setState(() => busy = true);
    try {
      if (signup) {
        await AuthService.signup(name.text, email.text, pass.text);
      } else {
        await AuthService.login(email.text, pass.text);
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString())));
      }
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 430),
            child: Card(
              child: Padding(
                padding: const EdgeInsets.all(22),
                child: Column(
                  children: [
                    const Icon(Icons.military_tech, size: 64),
                    const SizedBox(height: 12),
                    const Text('Maths Warrior', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 24),
                    if (signup) TextField(controller: name, decoration: const InputDecoration(labelText: 'Name')),
                    TextField(controller: email, decoration: const InputDecoration(labelText: 'Email')),
                    TextField(controller: pass, obscureText: true, decoration: const InputDecoration(labelText: 'Password')),
                    const SizedBox(height: 18),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: busy ? null : submit,
                        child: Text(busy ? 'Please wait' : signup ? 'Create Account' : 'Login'),
                      ),
                    ),
                    TextButton(
                      onPressed: () => setState(() => signup = !signup),
                      child: Text(signup ? 'Already have an account? Login' : 'New student? Create account'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget { const MainShell({super.key}); @override State<MainShell> createState()=>_MainShellState(); }
class _MainShellState extends State<MainShell> { int i=0; final pages=const [HomePage(),TestsPage(),HistoryPage(),ProfilePage()]; @override Widget build(BuildContext c)=>Scaffold(body:pages[i],bottomNavigationBar:NavigationBar(selectedIndex:i,onDestinationSelected:(v)=>setState(()=>i=v),destinations:const [NavigationDestination(icon:Icon(Icons.home_outlined),selectedIcon:Icon(Icons.home),label:'Home'),NavigationDestination(icon:Icon(Icons.quiz_outlined),selectedIcon:Icon(Icons.quiz),label:'Tests'),NavigationDestination(icon:Icon(Icons.history),label:'History'),NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile')])); }

class HomePage extends StatelessWidget { const HomePage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Maths Warrior')),body:ListView(padding:const EdgeInsets.all(16),children:[Card(child:ListTile(leading:const Icon(Icons.emoji_events),title:const Text('SSC GD Practice'),subtitle:const Text('Maths • Reasoning • GK/GS'),trailing:const Icon(Icons.arrow_forward_ios),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QuizSetupPage()))),),const SizedBox(height:10),const Text('Quick Start',style:TextStyle(fontSize:20,fontWeight:FontWeight.bold)),GridView.count(crossAxisCount:2,shrinkWrap:true,physics:const NeverScrollableScrollPhysics(),children:['Maths','Reasoning','GK/GS','Daily Quiz'].map((s)=>Card(child:InkWell(onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>QuizSetupPage(subject:s=='GK/GS'?'GK':s))),child:Center(child:Text(s,style:const TextStyle(fontWeight:FontWeight.bold)))))).toList()),const SizedBox(height:12),Card(child:ListTile(leading:const Icon(Icons.insights),title:const Text('My Performance'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const PerformancePage()))),)])); }

class TestsPage extends StatelessWidget { const TestsPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Tests')),body:ListView(padding:const EdgeInsets.all(16),children:[ListTile(tileColor:Theme.of(c).colorScheme.surfaceContainerHighest,leading:const Icon(Icons.timer),title:const Text('5 Minute Mixed Test'),subtitle:const Text('10 questions'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QuizSetupPage()))),const SizedBox(height:8),ListTile(leading:const Icon(Icons.menu_book),title:const Text('Topic Practice'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const QuizSetupPage(subject:'Maths')))),ListTile(leading:const Icon(Icons.analytics),title:const Text('My Performance'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const PerformancePage()))),ListTile(leading:const Icon(Icons.history),title:const Text('Test History'),onTap:()=>Navigator.push(c,MaterialPageRoute(builder:(_)=>const HistoryPage())))])); }

class QuizSetupPage extends StatefulWidget { final String? subject; const QuizSetupPage({super.key,this.subject}); @override State<QuizSetupPage> createState()=>_QuizSetupPageState(); }
class _QuizSetupPageState extends State<QuizSetupPage> { String subject='All', difficulty='All'; int count=10; bool loading=false; Future<void> start(){ setState(()=>loading=true); return DataService.questions(subject:subject=='All'?null:subject,difficulty:difficulty=='All'?null:difficulty,limit:count).then((q){if(!mounted)return; setState(()=>loading=false); if(q.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Questions not available')));return;} Navigator.push(context,MaterialPageRoute(builder:(_)=>QuizPage(title:'${subject} Practice',questions:q)));}).catchError((_) {if(mounted)setState(()=>loading=false);}); }
 @override void initState(){super.initState();if(widget.subject!=null)subject=widget.subject!;}
 @override
 Widget build(BuildContext c) {
  return Scaffold(
   appBar: AppBar(title: const Text('Start Test')),
   body: Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
     crossAxisAlignment: CrossAxisAlignment.start,
     children: [
      DropdownButtonFormField<String>(
       value: subject,
       decoration: const InputDecoration(labelText: 'Subject'),
       items: ['All','Maths','Reasoning','GK'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
       onChanged: (v) => setState(() => subject = v!),
      ),
      DropdownButtonFormField<String>(
       value: difficulty,
       decoration: const InputDecoration(labelText: 'Difficulty'),
       items: ['All','Easy','Medium','Hard'].map((x) => DropdownMenuItem(value: x, child: Text(x))).toList(),
       onChanged: (v) => setState(() => difficulty = v!),
      ),
      const SizedBox(height: 16),
      Text('Questions: $count'),
      Slider(value: count.toDouble(), min: 5, max: 20, divisions: 3, onChanged: (v) => setState(() => count = v.round())),
      const Spacer(),
      SizedBox(
       width: double.infinity,
       child: FilledButton.icon(onPressed: loading ? null : start, icon: const Icon(Icons.play_arrow), label: Text(loading ? 'Loading...' : 'Start Test')),
      ),
     ],
    ),
   ),
  );
 }

}

class QuizPage extends StatefulWidget { final String title; final List<Question> questions; const QuizPage({super.key,required this.title,required this.questions}); @override State<QuizPage> createState()=>_QuizPageState(); }
class _QuizPageState extends State<QuizPage> { int index=0,correct=0,wrong=0,unanswered=0; int? selected; Timer? timer; int seconds=300; bool finishing=false;
 @override void initState(){super.initState(); timer=Timer.periodic(const Duration(seconds:1),(_){ if (!mounted || finishing) return; if(seconds>1){setState(()=>seconds--);}else{seconds=0; finish();} });}
 void answer(int i){if(selected!=null)return;selected=i;setState((){});}
 void next(){if(selected==null)unanswered++;else if(selected==widget.questions[index].correctIndex)correct++;else wrong++; if(index==widget.questions.length-1){finish();}else{setState(()=>index++);selected=null;}}
 Future<void> finish() async { if (finishing) return; finishing=true; timer?.cancel(); final score=correct; try { await DataService.saveAttempt(title:widget.title,total:widget.questions.length,correct:correct,wrong:wrong,unanswered:unanswered,score:score); if(mounted){ await showDialog(context:context,barrierDismissible:false,builder:(_)=>AlertDialog(title:const Text('Test Complete'),content:Text('Correct: $correct\nWrong: $wrong\nUnanswered: $unanswered\nScore: $score'),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Done'))])); if(mounted) Navigator.pop(context); } } catch (e) { if(mounted){ finishing=false; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Could not save result: $e'))); } } }
 @override void dispose(){timer?.cancel();super.dispose();}
 @override
 Widget build(BuildContext c) {
  final q = widget.questions[index];
  final minutes = seconds ~/ 60;
  final secs = seconds % 60;
  return Scaffold(
   appBar: AppBar(
    title: Text('${index + 1}/${widget.questions.length}'),
    actions: [Padding(padding: const EdgeInsets.all(12), child: Center(child: Text('$minutes:${secs.toString().padLeft(2, '0')}')))],
   ),
   body: Padding(
    padding: const EdgeInsets.all(16),
    child: Column(
     crossAxisAlignment: CrossAxisAlignment.start,
     children: [
      LinearProgressIndicator(value: (index + 1) / widget.questions.length),
      const SizedBox(height: 18),
      Text('${q.subject} • ${q.topic}', style: Theme.of(c).textTheme.labelLarge),
      const SizedBox(height: 8),
      Text(q.question, style: const TextStyle(fontSize: 21, fontWeight: FontWeight.w600)),
      const SizedBox(height: 18),
      ...List.generate(q.options.length, (i) => Card(
       color: selected == i ? Theme.of(c).colorScheme.primaryContainer : null,
       child: ListTile(
        onTap: () => answer(i),
        leading: CircleAvatar(child: Text(String.fromCharCode(65 + i))),
        title: Text(q.options[i]),
       ),
      )),
      const Spacer(),
      Row(
       children: [
        if (q.explanation.isNotEmpty)
         TextButton(
          onPressed: () => showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Explanation'), content: Text(q.explanation), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))])),
          child: const Text('Explain'),
         ),
        const Spacer(),
        FilledButton(onPressed: next, child: Text(index == widget.questions.length - 1 ? 'Submit' : 'Next')),
       ],
      ),
     ],
    ),
   ),
  );
 }

}

class HistoryPage extends StatelessWidget { const HistoryPage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Test History')),body:StreamBuilder<QuerySnapshot<Map<String,dynamic>>>(stream:DataService.attempts(),builder:(c,s){if(s.connectionState==ConnectionState.waiting)return const Center(child:CircularProgressIndicator());final docs=s.data?.docs??[];if(docs.isEmpty)return const Center(child:Text('No tests attempted yet'));return ListView.builder(itemCount:docs.length,itemBuilder:(c,i){final m=docs[i].data();return Card(margin:const EdgeInsets.symmetric(horizontal:12,vertical:6),child:ListTile(title:Text('${m['title']??'Test'}'),subtitle:Text('Correct ${m['correct']??0} • Wrong ${m['wrong']??0} • ${((m['percentage']??0) as num).toStringAsFixed(1)}%'),trailing:Text('${m['score']??0}')));});})); }

class PerformancePage extends StatelessWidget { const PerformancePage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('My Performance')),body:StreamBuilder<DocumentSnapshot<Map<String,dynamic>>>(stream:DataService.db.collection('users').doc(AuthService.user!.uid).snapshots(),builder:(c,s){final m=s.data?.data()??{};return ListView(padding:const EdgeInsets.all(16),children:[_stat('Total Attempts','${m['attempts']??0}',Icons.quiz),_stat('Correct Answers','${m['correct']??0}',Icons.check_circle),_stat('Total Score','${m['score']??0}',Icons.star),const SizedBox(height:12),const Text('Keep practicing every day!',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold))]);}));}
 Widget _stat(String a,String b,IconData i)=>Card(child:ListTile(leading:Icon(i,size:32),title:Text(a),trailing:Text(b,style:const TextStyle(fontSize:24,fontWeight:FontWeight.bold))));

class ProfilePage extends StatelessWidget { const ProfilePage({super.key}); @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Profile')),body:ListView(padding:const EdgeInsets.all(16),children:[CircleAvatar(radius:42,child:Text((AuthService.user?.email??'U').substring(0,1).toUpperCase(),style:const TextStyle(fontSize:30))),const SizedBox(height:12),Center(child:Text(AuthService.user?.email??'',style:const TextStyle(fontWeight:FontWeight.bold))),const SizedBox(height:20),ListTile(leading:const Icon(Icons.logout),title:const Text('Logout'),onTap:()=>AuthService.logout())])); }
