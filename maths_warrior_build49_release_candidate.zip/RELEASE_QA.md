# Maths Warrior — Build 49 Release QA

- Package: com.mathswarrior.app
- Version: 49.0.0+49
- Firebase Android config: present
- Dart source files: main.dart, models.dart, services.dart, pages.dart
- Local SSC GD question bank asset: present
- Firestore rules: present

## Verified in this environment
- Source archive can be unpacked.
- Required project files are present.
- Android applicationId is `com.mathswarrior.app`.
- Android versionCode/versionName and pubspec version are aligned at 49/49.0.0.

## Not verified here
Flutter/Dart SDK is not installed in this environment, so `flutter pub get`, `flutter analyze`, and `flutter build apk --release` cannot be executed here.

## Build commands
```bash
flutter pub get
flutter analyze
flutter build apk --release
```
