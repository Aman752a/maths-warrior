plugins { id("com.android.application"); id("org.jetbrains.kotlin.android"); id("com.google.gms.google-services") }
android { namespace="com.mathswarrior.app"; compileSdk=35
 defaultConfig { applicationId="com.mathswarrior.app"; minSdk=23; targetSdk=35; versionCode=49; versionName="49.0.0" }
}
flutter { source="../.." }
