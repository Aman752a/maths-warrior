package com.mathswarrior.app
import io.flutter.embedding.android.FlutterActivity
class MainActivity: FlutterActivity()
